import React, { useState } from 'react';
import { Formik, Field, Form, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { useNavigate } from 'react-router-dom';
import axios from '../axios';
import './Registration.css'; // Import the CSS file for styling

// Validation schema using Yup
const validationSchema = Yup.object({
  firstName: Yup.string().required('First Name is required'),
  lastName: Yup.string().required('Last Name is required'),
  email: Yup.string().email('Invalid email address').required('Email is required'),
  password: Yup.string().min(6, 'Password must be at least 6 characters').required('Password is required'),
  gender: Yup.string().required('Gender is required'),
  phoneNumber: Yup.string().matches(/^[0-9]+$/, 'Phone number must be only digits').required('Phone Number is required'),
  profileImage: Yup.mixed().required('Profile Image is required'),
});

const Registration: React.FC = () => {
  const navigate = useNavigate();
  const [submitError, setSubmitError] = useState<string | null>(null); // Separate submit error state

  const initialValues = {
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    gender: 'male',
    phoneNumber: '',
    profileImage: null as File | null,
  };

  const handleSubmit = async (values: any, { setSubmitting, resetForm }: any) => {
    const data = new FormData();
    data.append('firstName', values.firstName);
    data.append('lastName', values.lastName);
    data.append('email', values.email);
    data.append('password', values.password);
    data.append('gender', values.gender);
    data.append('phoneNumber', values.phoneNumber);
    if (values.profileImage) {
      data.append('profileImage', values.profileImage);
    }

    try {
      await axios.post('/api/register', data, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      resetForm(); // Reset form on success
      navigate('/login'); // Redirect to login on success
    } catch (err: any) {
      setSubmitError(err.response?.data?.error || 'Something went wrong');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="registration-form-container">
      <h2 className="form-title">Retailer Registration</h2>
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        onSubmit={handleSubmit}
      >
        {({ setFieldValue, isSubmitting }) => (
          <Form className="registration-form" encType="multipart/form-data">
            {submitError && <div className="submit-error">{submitError}</div>}
            
            <div className="form-group">
              <label htmlFor="firstName">First Name</label>
              <Field type="text" name="firstName" className="form-input" />
              <ErrorMessage name="firstName" component="div" className="error-message" />
            </div>

            <div className="form-group">
              <label htmlFor="lastName">Last Name</label>
              <Field type="text" name="lastName" className="form-input" />
              <ErrorMessage name="lastName" component="div" className="error-message" />
            </div>

            <div className="form-group">
              <label htmlFor="email">Email</label>
              <Field type="email" name="email" className="form-input" />
              <ErrorMessage name="email" component="div" className="error-message" />
            </div>

            <div className="form-group">
              <label htmlFor="password">Password</label>
              <Field type="password" name="password" className="form-input" />
              <ErrorMessage name="password" component="div" className="error-message" />
            </div>

            <div className="form-group">
              <label htmlFor="gender">Gender</label>
              <Field as="select" name="gender" className="form-input">
                <option value="male">Male</option>
                <option value="female">Female</option>
              </Field>
              <ErrorMessage name="gender" component="div" className="error-message" />
            </div>

            <div className="form-group">
              <label htmlFor="phoneNumber">Phone Number</label>
              <Field type="tel" name="phoneNumber" className="form-input" />
              <ErrorMessage name="phoneNumber" component="div" className="error-message" />
            </div>

            <div className="form-group">
              <label htmlFor="profileImage">Profile Image</label>
              <input
                type="file"
                name="profileImage"
                className="form-input"
                accept="image/*"
                onChange={(e) => setFieldValue('profileImage', e.target.files ? e.target.files[0] : null)}
              />
              <ErrorMessage name="profileImage" component="div" className="error-message" />
            </div>

            <button type="submit" className="form-button" disabled={isSubmitting}>
              {isSubmitting ? 'Registering...' : 'Register'}
            </button>
          </Form>
        )}
      </Formik>
    </div>
  );
};

export default Registration;
