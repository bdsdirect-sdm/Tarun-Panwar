// src/components/ProductForm.tsx

import React, { useState } from 'react';
import { Formik, Field, Form, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const ProductForm: React.FC = () => {
  const navigate = useNavigate();
  const [imageFile, setImageFile] = useState<File | null>(null);

  const initialValues = {
    retailerId: '', // Assuming you'll get this from a context or prop
    name: '',
    description: '',
    price: '',
  };

  const validationSchema = Yup.object().shape({
    retailerId: Yup.number().required('Retailer ID is required'),
    name: Yup.string().required('Product name is required'),
    description: Yup.string(),
    price: Yup.number()
      .required('Price is required')
      .positive('Price must be a positive number')
      .typeError('Price must be a number'),
  });

  const handleSubmit = async (values: typeof initialValues) => {
    const formData = new FormData();
    formData.append('retailerId', values.retailerId.toString());
    formData.append('name', values.name);
    formData.append('description', values.description);
    formData.append('price', values.price.toString());
    if (imageFile) {
      formData.append('productImage', imageFile); // Append the image file
    }

    try {
      const token = localStorage.getItem('token'); // Retrieve token from localStorage (or any other storage)
      
      await axios.post('http://localhost:5000/api/addProduct', formData, {
        headers: {
          'Content-Type': 'multipart/form-data', // Set the content type for file upload
          'Authorization': `Bearer ${token}`, // Add the token in the Authorization header
        },
      });

      navigate('/products'); // Redirect after successful submission
    } catch (error) {
      console.error('Error adding product:', error);
      // Handle error appropriately
    }
  };

  return (
    <div>
      <h1>Add Product</h1>
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        onSubmit={handleSubmit}
      >
        {() => (
          <Form>
            <div>
              <label htmlFor="retailerId">Retailer ID</label>
              <Field name="retailerId" type="number" />
              <ErrorMessage name="retailerId" component="div" />
            </div>

            <div>
              <label htmlFor="name">Product Name</label>
              <Field name="name" type="text" />
              <ErrorMessage name="name" component="div" />
            </div>

            <div>
              <label htmlFor="description">Description</label>
              <Field name="description" as="textarea" />
              <ErrorMessage name="description" component="div" />
            </div>

            <div>
              <label htmlFor="price">Price</label>
              <Field name="price" type="number" />
              <ErrorMessage name="price" component="div" />
            </div>

            <div>
              <label htmlFor="productImage">Product Image</label>
              <input
                id="productImage"
                name="productImage"
                type="file"
                accept="image/png, image/jpeg"
                onChange={(event) => {
                  if (event.currentTarget.files) {
                    setImageFile(event.currentTarget.files[0]); // Set the selected file
                  }
                }}
              />
              <ErrorMessage name="productImage" component="div" />
            </div>

            <button type="submit">Add Product</button>
          </Form>
        )}
      </Formik>
    </div>
  );
};

export default ProductForm;
