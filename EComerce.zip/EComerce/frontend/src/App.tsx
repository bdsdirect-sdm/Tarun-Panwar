import { useState } from 'react'
import Registration from './components/Registration'
import { BrowserRouter, Routes ,Route} from 'react-router-dom'
import Login from './components/Login'
import AddProduct from './components/AddProduct'

function App() {

  return (
    <>
     <BrowserRouter>
     <Routes>
      <Route path={'/'} element={<Registration/>}/>
      <Route path={'/login'} element={<Login/>}/>
      <Route path={'/addProduct'} element={<AddProduct/>}/>
     </Routes>
     </BrowserRouter>
    </>
  )
}

export default App
