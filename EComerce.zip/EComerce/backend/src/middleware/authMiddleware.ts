import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';

const JWT_SECRET = '12345';

// Middleware to authenticate the retailer using JWT
export const authenticateRetailer = (req: any, res: any, next: NextFunction) => {
    const token = req.header("authorization")?.split(" ")[1];

    if (!token) {
      return res.status(401).json({ message: "No token provided." });
    }

    
    try {
      const decoded = jwt.verify(token, "secret_key");
      (req as any).userId = (decoded as any).id;
      next(); // Call next to move to the next middleware or route handler
    } catch (error) {
      return res.status(403).json({ message: "Failed to authenticate token." });
    }
};
