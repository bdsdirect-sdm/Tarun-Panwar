import { Router } from 'express';
import { addProduct, getProducts, getProductById, updateProduct, deleteProduct , register, login} from '../controllers/ProductControllers';
import { authenticateRetailer } from '../middleware/authMiddleware'; // Ensure you have authentication middleware
import { upload, upload1 } from '../middleware/multer';


const router = Router();



// Route to add a new product (requires authentication)
router.post('/register',upload , register);
router.post('/login', login);

router.post('/addProduct', authenticateRetailer, upload1, addProduct);

// Route to get all products with pagination (requires authentication)
router.get('/', authenticateRetailer, getProducts);

// Route to get a single product by its ID (requires authentication)
router.get('/:id', authenticateRetailer, getProductById);

// Route to update a product (requires authentication)
router.put('/:id', authenticateRetailer, updateProduct);

// Route to delete a product (requires authentication)
router.delete('/:id', authenticateRetailer, deleteProduct);

export default router;
