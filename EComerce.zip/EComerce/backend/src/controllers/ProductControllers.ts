import { Request, Response } from 'express';
import Product from '../models/Product';
import Retailer from '../models/Retailer';
import bcrypt from 'bcrypt';
import path from 'path';
import multer from 'multer';
import jwt from 'jsonwebtoken';
import { upload } from '../middleware/multer';
const JWT_SECRET = '12345';
// Multer setup for image uploads
// const storage = multer.diskStorage({
//     destination: function (req, file, cb) {
//       cb(null, 'uploads/'); // Destination folder for image uploads
//     },
//     filename: function (req, file, cb) {
//       cb(null, `${Date.now()}-${file.originalname}`);
//     }
//   });
  
//   const upload = multer({
//     storage: storage,
//     fileFilter: function (req, file, cb) {
//       const ext = path.extname(file.originalname).toLowerCase(); // Ensure lowercase for consistency
  
//       // Check for valid image file extensions
//       if (ext !== '.jpg' && ext !== '.jpeg' && ext !== '.png') {
//         return cb(null, false); // Reject the file, no error
//       }
//       cb(null, true); // Accept the file
//     }
//   }).single('profileImage'); // Use .single for single file uploads
  
  // Register controller function
  export const register = async (req: any, res: any) => {
    // console.log("files",req.files.profileImage[0].filename)
    try {
      const {
        firstName,
        lastName,
        email,
        phoneNumber,
        gender,
        password,
      } = req.body;
      
      // Check if required fields are provided
      if (!firstName || !lastName || !email || !phoneNumber || !gender) {
        return res.status(400).json({ message: "All fields are required" });
      }
  
      // Check if the user already exists
      const existingUser = await Retailer.findOne({ where: { email } });
      if (existingUser) {
        return res.status(400).json({ message: "Email already registered" });
      }
  
      // Hash the password
      const hashedPassword = await bcrypt.hash(password, 10);
  
      // Get the uploaded file (single file)
      const profileImage =req.files.profileImage[0].filename;
  
      // Log the uploaded file for debugging
      console.log("Uploaded profileImage:", profileImage);
  
      // Create the new user in the database
      const user = await Retailer.create({
        firstName,
        lastName,
        email,
        phoneNumber,
        gender,
        profileImage,
        password: hashedPassword,
      });
      console.log("user",user);
  
      return res.status(201).json({ message: "User Registered Successfully", user });
    } catch (error) {
      console.error("Error during registration:", error);
      return res.status(500).json({ error: "Internal server error" });
    }
  };

  export const login = async (req: any, res: any) => {
    try {
      const { email, password } = req.body;
  
      // Check if email and password are provided
      if (!email || !password) {
        return res.status(400).json({ message: "Email and password are required" });
      }
  
      // Find the user by email
      const user = await Retailer.findOne({ where: { email } });
  
      // If user does not exist, return error
      if (!user) {
        return res.status(400).json({ message: "Invalid email or password" });
      }
  
      // Compare the provided password with the stored hashed password
      const isPasswordValid = await bcrypt.compare(password, user.password);
  
      // If the password is invalid, return error
      if (!isPasswordValid) {
        return res.status(400).json({ message: "Invalid email or password" });
      }
  
      // Generate JWT token (optional)
      const token = jwt.sign({ id: user.id, email: user.email }, "secret_key", { expiresIn: '1h' });

      // Respond with user data and token (or any other session mechanism)
      return res.status(200).json({
        message: "Login successful",
        token,    // Optional, only if you're using JWT
        user: {
          id: user.id,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
        },
      });
    } catch (error) {
      console.error("Error during login:", error);
      return res.status(500).json({ error: "Internal server error" });
    }
  };


// Controller to add a new product
export const addProduct = async (req: any, res: any) => {
    // console.log("Req Files:", req.body); 
    
    
    // Handle any errors from Multer if they exist
    if (req.files?.productImage) {
      try {
        const { products } = req.body;
        const retailerId = req.user.id; // Assuming retailer ID is added to req.user from auth middleware
        console.log(retailerId);
        const createdProducts = [];
    
        for (const product of products) {
          const { name, description, price } = product;
  
          const newProduct = await Product.create({
            name,
            description,
            price,
            retailerId,
            productImage: req.files.productImage[0].filename,
          });
          console.log(newProduct);
    
          createdProducts.push(newProduct);
        }
    
        return res.status(201).json(createdProducts);
      } catch (error) {
        return res.status(500).json({ error: 'Unable to add products' });
      }
    } else {
      return res.status(400).json({ error: 'No product images were uploaded' });
    }
  };
  
  

// Controller to get all products of the logged-in retailer with pagination
export const getProducts = async (req:any, res: any) => {
  const retailerId = req.user.id;
  const { page = 1, limit = 10 } = req.query; // Default pagination

  try {
    const products = await Product.findAndCountAll({
      where: { retailerId },
      limit: Number(limit),
      offset: (Number(page) - 1) * Number(limit),
    });

    return res.status(200).json({
      products: products.rows,
      totalItems: products.count,
      totalPages: Math.ceil(products.count / Number(limit)),
      currentPage: Number(page),
    });
  } catch (error) {
    return res.status(500).json({ error: 'Unable to fetch products' });
  }
};

// Controller to get a single product by ID, ensuring the retailer owns the product
export const getProductById = async (req: any, res: any) => {
  const { id } = req.params;
  const retailerId = req.user.id;

  try {
    const product = await Product.findOne({ where: { id, retailerId } });

    if (!product) {
      return res.status(404).json({ error: 'Product not found or you do not have access' });
    }

    return res.status(200).json(product);
  } catch (error) {
    return res.status(500).json({ error: 'Unable to fetch product' });
  }
};

// Controller to update an existing product, ensuring the retailer owns the product
export const updateProduct = async (req: any, res: any) => {
    console.log(req.body);
  upload(req, res, async (err) => {
    if (err instanceof multer.MulterError || err) {
      return res.status(400).json({ error: err.message });
    }

    const { id } = req.params;
    const { name, description, price } = req.body;
    const retailerId = req.user.id; // Assuming retailer ID is added to req.user from auth middleware

    try {
      const product = await Product.findOne({ where: { id, retailerId } });

      if (!product) {
        return res.status(404).json({ error: 'Product not found or you do not have access' });
      }

      const updatedProduct = await product.update({
        name: name || product.name,
        description: description || product.description,
        price: price || product.price,
        imageUrl: req.file?.path || product.imageUrl
      });

      return res.status(200).json(updatedProduct);
    } catch (error) {
      return res.status(500).json({ error: 'Unable to update product' });
    }
  });
};

// Controller to delete a product, ensuring the retailer owns the product
export const deleteProduct = async (req: any, res: any) => {
  const { id } = req.params;
  const retailerId = req.user.id;

  try {
    const product = await Product.findOne({ where: { id, retailerId } });

    if (!product) {
      return res.status(404).json({ error: 'Product not found or you do not have access' });
    }

    await product.destroy();
    return res.status(200).json({ message: 'Product deleted successfully' });
  } catch (error) {
    return res.status(500).json({ error: 'Unable to delete product' });
  }
};
