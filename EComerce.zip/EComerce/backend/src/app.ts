import express, { Application, Request, Response } from 'express';
import cors from 'cors';
import helmet from 'helmet';
import dotenv from 'dotenv';
import productRoutes from '../src/routes/retailerProduct';
import sequelize  from './config/db'; // Your sequelize setup file
import path from 'path';

dotenv.config();

const app: Application = express();

// Middleware setup
app.use(helmet()); // For security headers
app.use(cors()); // For Cross-Origin Resource Sharing
app.use(express.json()); // For parsing JSON bodies
app.use('/uploads', express.static(path.join(__dirname, '../', 'uploads')));
console.log(__dirname,'../',"uploads")
// Product routes
app.use('/api', productRoutes);

// Health check route
app.get('/', (req: Request, res: Response) => {
  res.send('Retailer Shopping App API');
});

// Sync database and start server
const PORT = process.env.PORT || 5000;

sequelize.sync({ alter: true }) // Syncs the models with the database, no data loss if force: false
  .then(() => {
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  })
  .catch((err: any) => {
    console.error('Unable to connect to the database:', err);
  });
