import { Model, DataTypes, ForeignKey } from 'sequelize';
import  sequelize  from '../config/db';
import Retailer  from './Retailer';

class Product extends Model {
  public id!: number;
  public retailerId!: number;
  public name!: string;
  public description!: string;
  public price!: number;
  public imageUrl?: string;

  public readonly createdAt!: Date;
  public readonly updatedAt!: Date;
}

Product.init({
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  retailerId: {
    type: DataTypes.INTEGER,
    references: {
      model: Retailer,
      key: 'id',
    },
    allowNull: false,
    onDelete: 'CASCADE',
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  description: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  price: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false,
  },
  productImage: {
    type: DataTypes.STRING,
    allowNull: true,
  },
}, {
  sequelize,
  modelName: 'Product',
  tableName: 'products',
});

// Association
Retailer.hasMany(Product, {
  foreignKey: 'retailerId',
  as: 'products',
});
Product.belongsTo(Retailer, {
  foreignKey: 'retailerId',
  as: 'retailer',
});


export default Product;
