import React, { useEffect, useRef, useState } from "react";
import { io, Socket } from "socket.io-client";
import {
  Button,
  Container,
  TextField,
  Typography,
  Box,
  Stack,
} from "@mui/material";
import { useParams } from "react-router-dom";
import axios from "axios";

const Chat: React.FC = () => {
  const { id } = useParams();

  // Initialize socket connection

  const socket = useRef<Socket | null>(null);
  // socket.current = io('http://localhost:9000');

  // Use useRef to hold the socket instance

  // Define state types
  const [message, setMessage] = useState<string>("");
  const [room, setRoom] = useState<string>("");
  const [socketID, setSocketID] = useState<string>("");
  const [messages, setMessages] = useState<string[]>([]);
  const [roomName, setRoomName] = useState<string>("");
  const [history, setHistory] = useState<any>([]);

  const senderId = localStorage.getItem("userId");
  const receiverId = id;

  // console.log(senderId );
  // Fetch messages when the component mounts or when id changes
  useEffect(() => {
    socket.current = io("http://localhost:9000");

    socket.current.on("connect", () => {
      console.log(socket.current?.id);
      setSocketID(socket.current?.id || "");
      console.log("connected", socket.current?.id);
    });

    socket.current.emit("join-room", senderId, receiverId);

    socket.current.emit("get-histories", { senderId, receiverId });

    socket.current.on("histories", (data) => {
      console.log(data,"........................")
      setHistory(data);
    });
    // console.log(senderId , receiverId);

    socket.current.on("receive-message", (data: string) => {
      console.log("receive-message", data);
      setMessages((messages) => [...messages, data]);
    });

    // console.log(senderId , receiverId);
    // Fetch messages for the specific id

    // Initialize socket connection
    // socket.current = io('http://localhost:9000');

    // Listen for socket connection
    // socket.current.on('connect', () => {
    //   console.log(socket.current?.id);
    //   setSocketID(socket.current?.id || '');
    //   console.log('connected', socket.current?.id);
    // });

    // Listen for received messages
    // socket.current.on('receive-message', (data: string) => {
    //   console.log('receive-message', data);
    //   setMessages((messages) => [...messages, data]);
    // });

    // Cleanup on disconnection
    return () => {
      socket.current?.disconnect();
    };
  }, [id , messages]); // Re-run effect when id changes

  // Handle message send
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    socket.current?.emit("send-message", { message, senderId, receiverId });

    // try {
    //   const response = await axios.post(
    //     "http://localhost:9000/api/send-message",
    //     {
    //       id,
    //       content: message,
    //     }
    //   );
      

    //   if (response.status === 200) {
    //     console.log("Message sent and saved successfully:", response.data);
    //   } else {
    //     console.log("Failed to send message:", response);
    //   }
    // } catch (error) {
    //   console.error("Error sending message:", error);
    // }

    setMessage("");
  };

  // Handle joining a room
  // const joinRoomHandler = (e: React.FormEvent) => {
  //   console.log('room', roomName );
  //   e.preventDefault();
  //   socket.current?.emit('join-room', roomName);
  //   console.log('Receiver Id', roomName);
  //   setRoomName('');
  // };

  return (
<Container maxWidth="sm" sx={{ backgroundColor: "#f9f9f9", borderRadius: "8px", padding: "20px", boxShadow: "0px 0px 10px rgba(0,0,0,0.1)" }}>
      <Typography variant="h6" sx={{ color: "#333", marginBottom: "20px" }}>
        Socket ID: {socketID || "Connecting..."}
      </Typography>

      <Stack spacing={2} sx={{ maxHeight: "400px", overflowY: "auto", marginBottom: "20px" }}>
        {history.map((msg: any, i: any) => (
          <Box key={i} sx={{
            alignSelf: msg.senderId === senderId ? 'flex-end' : 'flex-start',
            backgroundColor: msg.senderId === senderId ? "#d1e7dd" : "#ffffff",
            padding: "10px",
            borderRadius: "10px",
            maxWidth: "70%",
            wordWrap: "break-word",
            display: 'flex',
            justifyContent: msg.senderId === senderId ? 'flex-end' : 'flex-start',
          }}>
            <Typography variant="body1" sx={{ color: "#333" }}>
              {msg.content}
            </Typography>
          </Box>
        ))}
      </Stack>

      <form onSubmit={handleSubmit} style={{ display: 'flex', alignItems: 'center' }}>
        <TextField
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          label="Type a message"
          variant="outlined"
          fullWidth
          sx={{ marginRight: '10px' }}
        />
        <Button type="submit" variant="contained" color="primary" sx={{
          "&:hover": {
            backgroundColor: "#0056b3",
          },
        }}>
          Send
        </Button>
      </form>
    </Container>
  );
};

export default Chat;
