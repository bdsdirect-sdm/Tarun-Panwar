import express, { Request, Response } from 'express';
import sequelize from '../src/config/db'
import User from './models/User';
import UserRoutes from './routes/UserRoutes';
import { Server, Socket } from 'socket.io';
import cors from 'cors';
import path from 'path';
import ChatRoom from './models/ChatRoom';
import Message from './models/Message';
import http from 'http';

const app = express();
app.use(cors());
const server = http.createServer(app);  // Use the HTTP server for Socket.io

// Socket.io setup
const io = new Server(server, {
  cors: {
    origin: '*',  // You can specify the origin or '*' for all
    methods: ['GET', 'POST']
  }
});

// Set up socket.io connection
io.on('connection', (socket: Socket) => {
  console.log('A user connected:', socket.id);
   // Handle joining a room
   socket.on('join-room', (senderId:number , receiverId:number) => {
    console.log(`User ${senderId} joined room with ${receiverId}`);
    const room:any = [senderId, receiverId]?.sort().join("");
    socket.join(room); 
    console.log(`${socket.id} joined room: ${room} ${senderId} - ${receiverId}`);
  });

  // Example event to listen for incoming messages
  socket.on('send-message', async ({ message , receiverId , senderId }) => {
    const room:any = [senderId, receiverId]?.sort().join("");
    console.log(`Message from ${senderId} to ${receiverId}: ${message}`);    

    try {

        // If no existing chat room, create a new one
        const chatRoom:any = await ChatRoom.create({
          senderId,
          receiverId,
          room,
          content: message,  // Optionally, store the initial content in the room itself
        });
        console.log('New chat room created:', chatRoom);
        console.log(message)
        socket.to(room).emit("receive-message", message);

      }

      // Send the message to everyone in the room except the sender
      
      catch (error) {
        console.error('Error saving message to DB:', error);
      }
    
  });


  socket.on('get-histories', async ({ receiverId , senderId }) => {
    const room:any = [senderId, receiverId]?.sort().join(""); 

    try {
        // If no existing chat room, create a new one
        const chatRoom:any = await ChatRoom?.findAll({where:{room}});
        
        socket.emit("histories", chatRoom);
      }

      // Send the message to everyone in the room except the sender
      
      catch (error) {
        console.error('Error saving message to DB:', error);
      }
    
  });

});

// Middleware and Routes
app.use(express.json());
const PORT = process.env.PORT || 9000;
app.use('/uploads', express.static(path.join(__dirname, '../', 'uploads')));
app.use('/api', UserRoutes);

app.get('/', (req: Request, res: Response) => {
  res.send('Hello, TypeScript with Express!');
});

// Starting the server
const startServer = async () => {
  try {
    await sequelize.sync({ alter: true });  // Sync database
    // console.log(await Message.findAll());
    server.listen(PORT, () => {
      console.log(`Server is running on http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error('Unable to connect to the database:', error);
  }
};

startServer();
